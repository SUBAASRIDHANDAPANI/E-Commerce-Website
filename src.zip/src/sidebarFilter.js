import React from "react";
import "./styles.scss";
const Side = () => {
  return (
    <div className="full">
      <div className="side">
        <h4>Filter</h4>
        <h4>Filter</h4>
        <h4>Filter</h4>
      </div>
    </div>
  );
};
export default Side;
