import React, { useState } from 'react';
import { Button, Stack, TextField, Typography, Box } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const LoginForm = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const Navigate=useNavigate()
  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle login logic here, e.g., send a request to your server
   Navigate("Display")

  };

  return (
    <Stack
      direction="column"
      alignItems="center"
      marginTop="60px"
      height="100vh"

       // Adjust as needed
    >
      <form onSubmit={handleSubmit}>
        <Typography variant="h5" gutterBottom>
          Login
        </Typography>
        <Stack direction="column" spacing={2} style={{width:"500px"}}>
          <TextField
            label="Email"
            type="email"
        
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <TextField
            label="Password"
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </Stack>
        <Box mt={2}>
          <Button type="submit" variant="contained" color="primary"
          size="large">
            Login
          </Button>
        </Box>
      </form>
    </Stack>
  );
};

export default LoginForm;
