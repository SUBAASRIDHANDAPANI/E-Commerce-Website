import React from "react";
import './styles.scss';
import image from "./ecom.png";
import {useNavigate} from "react-router-dom";
// import View from "./view";
const Display = () => {
  const Navigate=useNavigate()
  return (
    
          <div className="header">
          <span className="logo">
          <img src={image} alt=""></img>
          </span>
          <span id="brand">ebuy</span>
        
        <span className="logreg">
       
          <button id="login" onClick={()=>Navigate("login")}>LogIn</button>
      
         
          <button id="register"  onClick={()=>Navigate("register")}>Register</button>
         
        
        </span>
          

    </div>
  );
};
export default Display;
