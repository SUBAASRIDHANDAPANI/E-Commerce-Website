// import React, { useState } from "react";

// const ProductDetails = ({ products, navigateToHome }) => {
//   const [cartCount, setCartCount] = useState(0);

//   // Calculate the total price and update cart count
//   const totalAmount = products.reduce(
//     (total, product) => total + product.quantity * product.price,
//     0
//   );

//   // Function to decrement item quantity
//   const handleDecrement = (product) => {
//     if (product.quantity > 1) {
//       product.quantity--;
//       setCartCount(cartCount - 1);
//     }
//   };

//   // Function to increment item quantity
//   const handleIncrement = (product) => {
//     product.quantity++;
//     setCartCount(cartCount + 1);
//   };

//   return (
//     <div>
//       <h4>Cart Details</h4>
//       {products.map((product) => (
//         <div key={product.id}>
//           <h2>{product.title}</h2>
//           <p>Category: {product.category}</p>
//           <p>Price: ${product.price}</p>
//           <img
//             style={{
//               height: "200px",
//               width: "150px",
//             }}
//             src={product.image}
//             alt={product.title}
//           />
//           <p>Total Price: ${product.quantity * product.price}</p>
//           <span>
//             <button onClick={() => handleDecrement(product)}>-</button>
//             <span>Quantity: {product.quantity}</span>
//             <button onClick={() => handleIncrement(product)}>+</button>
//           </span>
//         </div>
//       ))}
//       <p>Grand Total: ${totalAmount}</p>
//       <button onClick={navigateToHome}>Back to Home</button>
//     </div>
//   );
// };

// export default ProductDetails;


// import React,{useState} from "react";
// import { FaArrowLeft } from "react-icons/fa";

// const ProductDetails = ({ products, navigateToHome }) => {
//   // Calculate the total price of items in the cart
//     const [cartCount, setCartCount] = useState(0);

//   const totalPrice = products.reduce(
//     (total, product) => total + product.price * product.quantity,
//     0
//   );
//   const handleDecrement = (product) => {
//         if (product.quantity > 1) {
//           product.quantity--;
//           setCartCount(cartCount - 1);
//         }
//       };
    
//       // Function to increment item quantity
//       const handleIncrement = (product) => {
//         product.quantity++;
//         setCartCount(cartCount + 1);
//       };
//   return (
//     <div className="product-details-container">
//       <div className="product-details-header">
//         <FaArrowLeft
//           size={25}
//           onClick={() => {
//             navigateToHome();
//           }}
//         />
//         <h2>Cart</h2>
//       </div>
//       <span className="product-details">
//         {products.map((product) => (
//           <span key={product.id} className="product-detail">
//             <h3>{product.title}</h3>
//             <p>Category: {product.category}</p>
//             <p>Price: ${product.price}</p>
//             <img style={{height:"200px",
//              width: "150px",
//              }}
//             src={product.image} />
//           <div>
//    <button onClick={() => handleDecrement(product)}>-</button>
//    <span>Quantity: {product.quantity}</span>
//   <button onClick={() => handleIncrement(product)}>+</button>
// </div>
      
//             <p>Total Price: ${product.price * product.quantity}</p>
//           </span>
//         ))}
//       </span>
//       <div className="total-price">
//         <h3>Total Price: ${totalPrice}</h3>
//       </div>
//     </div>
//   );
// };

// export default ProductDetails;


// import React from 'react';
// const ProductDetails=()=>{
//   return(
//     <h2>hello</h2>
//   )
// }
// export  default ProductDetails;

import React from 'react';

const ProductDetails = ({ products }) => {
  if (!Array.isArray(products)) {
    return(<h2>NULL</h2>)
    ; // Return nothing if products is not an array
  }

  return (
    <div>
      <h2>Cart Products</h2>
      <ul>
        {products.map((product) => (
          <li key={product.id}>
            <h3>{product.title}</h3>
            <p>Category: {product.category}</p>
            <p>Price: ${product.price}</p>
            <p>Quantity: {product.quantity}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ProductDetails;
